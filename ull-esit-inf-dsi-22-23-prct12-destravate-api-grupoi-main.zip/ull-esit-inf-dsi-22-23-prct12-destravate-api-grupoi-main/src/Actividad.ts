/**
 * Enum para el tipo de actividad
 * @enum
 * @param Bicicleta
 * @param Correr
 */
export enum Actividad{
    Bicicleta,
    Correr,
}